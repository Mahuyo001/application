﻿#ifndef PCH_H
#define PCH_H

// TODO: add headers that you want to pre-compile here
#include <Windows.h>
#include <d3d9.h>
#include <d3d11.h>

int dx11_test();


#endif //PCH_H
