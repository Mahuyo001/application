#define BUILD_VERSION_NAME "version: unknown" 
#define BUILD_VERSION_REV 0
