﻿#pragma once

#include "targetver.h"
#define WIN32_LEAN_AND_MEAN 
#define _CRT_SECURE_NO_WARNINGS

#include <windows.h>
#include <d3d9.h>
#include <d3d11.h>
#include <stdarg.h>
#include "..\include\gw2al_api.h"
#include "version.h"
#include "id_storage.h"
#include "gw2al_api_impl.h"
#include "loader_core.h"
