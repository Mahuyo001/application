---
name: Addon request
about: Know of a sweet addon that's not supported? Request it here.
title: ''
labels: enhancement
assignees: ''

---

**Name**
What's it called?

**Website Link**
(Can be more than one link) Git repo, standalone blog, wherever someone can read about and download the addon.

**Anything else** (Optional)
Why you like this addon, what it does, how it works...anything.
