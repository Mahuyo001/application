---
name: Bug report
about: For when anything is broken or behaving unexpectedly.
title: ''
labels: bug
assignees: ''

---

### Please attach a copy of config.yaml or config.ini to the issue.

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
List steps to reproduce the bug, if possible.

**Additional context**
Add any other context about the problem here.

**don't forget to attach the config file to the issue**
