﻿using System.Windows.Navigation;

/*
 * Matthew Lee
 * Summer 2019
 * Guild Wars 2 Add-On Updater
 */

namespace GW2_Addon_Manager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : NavigationWindow
    {
        /// <summary>
        /// Initializes the application's main window.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
