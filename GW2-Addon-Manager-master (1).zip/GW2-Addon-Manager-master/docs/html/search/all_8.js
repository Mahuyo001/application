var searchData=
[
  ['openingviewmodel_37',['OpeningViewModel',['../class_g_w2___addon___manager_1_1_opening_view_model.html',1,'GW2_Addon_Manager.OpeningViewModel'],['../class_g_w2___addon___manager_1_1_opening_view_model.html#a5d053e37e0bea4901d6a056b6fb9c45f',1,'GW2_Addon_Manager.OpeningViewModel.OpeningViewModel()']]]
];
