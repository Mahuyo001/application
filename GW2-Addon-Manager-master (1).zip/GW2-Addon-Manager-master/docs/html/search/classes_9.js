var searchData=
[
  ['selfupdate_75',['SelfUpdate',['../class_g_w2___addon___manager_1_1_self_update.html',1,'GW2_Addon_Manager']]],
  ['settings_76',['Settings',['../class_g_w2___addon___manager_1_1_properties_1_1_settings.html',1,'GW2_Addon_Manager::Properties']]]
];
