var searchData=
[
  ['pluginmanagement_38',['PluginManagement',['../class_g_w2___addon___manager_1_1_plugin_management.html',1,'GW2_Addon_Manager']]],
  ['propertychanged_39',['PropertyChanged',['../class_g_w2___addon___manager_1_1_addon_info.html#a2b5b8cef709a8b9261f8cadfa53a7265',1,'GW2_Addon_Manager.AddonInfo.PropertyChanged()'],['../class_g_w2___addon___manager_1_1_opening_view_model.html#abe170379989001bacd1afb3db24efbbd',1,'GW2_Addon_Manager.OpeningViewModel.PropertyChanged()'],['../class_g_w2___addon___manager_1_1_updating_view_model.html#a75e743d2a78e3f48ca41656e7552a0eb',1,'GW2_Addon_Manager.UpdatingViewModel.PropertyChanged()'],['../class_g_w2___addon___manager_1_1_opening_view_model.html#a4605991ac641ae33f6c8e5ddeefdb300',1,'GW2_Addon_Manager.OpeningViewModel.propertyChanged()'],['../class_g_w2___addon___manager_1_1_updating_view_model.html#a3fb3ccda33c0ef00babc9aff1573ede7',1,'GW2_Addon_Manager.UpdatingViewModel.propertyChanged()']]]
];
