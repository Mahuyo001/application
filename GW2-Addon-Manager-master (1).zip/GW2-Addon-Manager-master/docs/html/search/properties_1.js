var searchData=
[
  ['closebuttonenabled_109',['closeButtonEnabled',['../class_g_w2___addon___manager_1_1_updating_view_model.html#a09ddfbd07abc80fbc758fb233e7e11cf',1,'GW2_Addon_Manager::UpdatingViewModel']]],
  ['createshortcut_110',['CreateShortcut',['../class_g_w2___addon___manager_1_1_opening_view_model.html#ae309baf9ad67a7afd3e66a17e8818cdc',1,'GW2_Addon_Manager::OpeningViewModel']]]
];
