var searchData=
[
  ['openingviewmodel_72',['OpeningViewModel',['../class_g_w2___addon___manager_1_1_opening_view_model.html',1,'GW2_Addon_Manager']]]
];
