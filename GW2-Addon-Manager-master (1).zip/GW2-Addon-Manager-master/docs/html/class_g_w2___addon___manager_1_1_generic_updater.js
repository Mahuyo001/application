var class_g_w2___addon___manager_1_1_generic_updater =
[
    [ "GenericUpdater", "class_g_w2___addon___manager_1_1_generic_updater.html#a37d1a3d142b5b11397efa0b315367216", null ],
    [ "Update", "class_g_w2___addon___manager_1_1_generic_updater.html#a70a7ebe16e3c76a53cbe78fbc512c269", null ]
];