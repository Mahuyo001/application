var class_g_w2___addon___manager_1_1_approved_list =
[
    [ "FetchListFromRepo", "class_g_w2___addon___manager_1_1_approved_list.html#a33d7e7dc5363ca329b94fd10835e4f00", null ]
];