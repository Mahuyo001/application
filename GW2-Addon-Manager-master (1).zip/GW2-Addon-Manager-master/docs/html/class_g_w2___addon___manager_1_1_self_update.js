var class_g_w2___addon___manager_1_1_self_update =
[
    [ "SelfUpdate", "class_g_w2___addon___manager_1_1_self_update.html#afa6b143dc9e3b03d17b35264f770f977", null ],
    [ "downloadLatestRelease", "class_g_w2___addon___manager_1_1_self_update.html#a64ab40e3b2b11923c33ad359899f7ca0", null ]
];