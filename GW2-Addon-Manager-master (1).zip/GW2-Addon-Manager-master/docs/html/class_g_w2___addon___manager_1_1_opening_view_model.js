var class_g_w2___addon___manager_1_1_opening_view_model =
[
    [ "OpeningViewModel", "class_g_w2___addon___manager_1_1_opening_view_model.html#a5d053e37e0bea4901d6a056b6fb9c45f", null ],
    [ "propertyChanged", "class_g_w2___addon___manager_1_1_opening_view_model.html#a4605991ac641ae33f6c8e5ddeefdb300", null ],
    [ "AddonList", "class_g_w2___addon___manager_1_1_opening_view_model.html#a4acf7f50b61025483d4fc70265a17cfa", null ],
    [ "AddonWebsite", "class_g_w2___addon___manager_1_1_opening_view_model.html#a2c23c06369c08e8d25fe5ece5824e6af", null ],
    [ "CreateShortcut", "class_g_w2___addon___manager_1_1_opening_view_model.html#ae309baf9ad67a7afd3e66a17e8818cdc", null ],
    [ "DeleteSelected", "class_g_w2___addon___manager_1_1_opening_view_model.html#a49ac11eb2e97a05e7f107b1bf65de7a2", null ],
    [ "DescriptionText", "class_g_w2___addon___manager_1_1_opening_view_model.html#aa4739a385307f8df0be004f9529e163a", null ],
    [ "Developer", "class_g_w2___addon___manager_1_1_opening_view_model.html#a1a881744d3980a3a99ac2e1ca65aa775", null ],
    [ "DeveloperVisibility", "class_g_w2___addon___manager_1_1_opening_view_model.html#a069418c57927cb245223afb9016a80e2", null ],
    [ "DisableSelected", "class_g_w2___addon___manager_1_1_opening_view_model.html#a39967b1d244a35ae0fc09e9d2388a73f", null ],
    [ "DownloadSelfUpdate", "class_g_w2___addon___manager_1_1_opening_view_model.html#a5d208f54c5b478961f9e9aa5084fedd3", null ],
    [ "EnableSelected", "class_g_w2___addon___manager_1_1_opening_view_model.html#a94aac9aaa051193ca94e33ee398d681c", null ],
    [ "GamePath", "class_g_w2___addon___manager_1_1_opening_view_model.html#a01de9d4d1d2389ad602418af9aed8721", null ],
    [ "SelectedAddons", "class_g_w2___addon___manager_1_1_opening_view_model.html#aaf6c559cb91821a824a3665f62e75c7e", null ],
    [ "SetDefaultAddons", "class_g_w2___addon___manager_1_1_opening_view_model.html#a940c70d165cd848672608d0a8fba9f2a", null ],
    [ "SetGamePath", "class_g_w2___addon___manager_1_1_opening_view_model.html#a4b8436daf09d8184cd05171395eeccf7", null ],
    [ "UpdateAvailable", "class_g_w2___addon___manager_1_1_opening_view_model.html#a08d66930b3981dbb8fbe2fe46de460dc", null ],
    [ "UpdateDownloadProgress", "class_g_w2___addon___manager_1_1_opening_view_model.html#a1b7e298fa130d5f7a84a30f211b12636", null ],
    [ "UpdateLinkVisibility", "class_g_w2___addon___manager_1_1_opening_view_model.html#afc51f06b6c03bccd925d66f7ebb21596", null ],
    [ "UpdateProgressVisibility", "class_g_w2___addon___manager_1_1_opening_view_model.html#a1107d26a888b25a76e0760c74a597fbc", null ],
    [ "PropertyChanged", "class_g_w2___addon___manager_1_1_opening_view_model.html#abe170379989001bacd1afb3db24efbbd", null ]
];