var namespaces_dup =
[
    [ "GW2_Addon_Manager", "namespace_g_w2___addon___manager.html", null ]
];