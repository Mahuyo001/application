var annotated_dup =
[
    [ "GW2_Addon_Manager", "namespace_g_w2___addon___manager.html", "namespace_g_w2___addon___manager" ],
    [ "GW2_Addon_Updater", null, [
      [ "Add_On_Selector", "class_g_w2___addon___updater_1_1_add___on___selector.html", null ],
      [ "Updating", "class_g_w2___addon___updater_1_1_updating.html", null ]
    ] ],
    [ "XamlGeneratedNamespace", null, [
      [ "GeneratedInternalTypeHelper", "class_xaml_generated_namespace_1_1_generated_internal_type_helper.html", null ]
    ] ]
];