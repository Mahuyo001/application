var namespace_g_w2___addon___manager =
[
    [ "Properties", null, [
      [ "Resources", "class_g_w2___addon___manager_1_1_properties_1_1_resources.html", null ],
      [ "Settings", "class_g_w2___addon___manager_1_1_properties_1_1_settings.html", null ]
    ] ],
    [ "Resources", null, [
      [ "Components", null, [
        [ "dropdown", "class_g_w2___addon___manager_1_1_resources_1_1_components_1_1dropdown.html", null ]
      ] ]
    ] ],
    [ "AddonInfo", "class_g_w2___addon___manager_1_1_addon_info.html", "class_g_w2___addon___manager_1_1_addon_info" ],
    [ "AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
    [ "AddonYamlReader", "class_g_w2___addon___manager_1_1_addon_yaml_reader.html", null ],
    [ "App", "class_g_w2___addon___manager_1_1_app.html", null ],
    [ "ApprovedList", "class_g_w2___addon___manager_1_1_approved_list.html", "class_g_w2___addon___manager_1_1_approved_list" ],
    [ "Configuration", "class_g_w2___addon___manager_1_1_configuration.html", null ],
    [ "GenericUpdater", "class_g_w2___addon___manager_1_1_generic_updater.html", "class_g_w2___addon___manager_1_1_generic_updater" ],
    [ "LoaderSetup", "class_g_w2___addon___manager_1_1_loader_setup.html", "class_g_w2___addon___manager_1_1_loader_setup" ],
    [ "MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
    [ "OpeningViewModel", "class_g_w2___addon___manager_1_1_opening_view_model.html", "class_g_w2___addon___manager_1_1_opening_view_model" ],
    [ "PluginManagement", "class_g_w2___addon___manager_1_1_plugin_management.html", null ],
    [ "SelfUpdate", "class_g_w2___addon___manager_1_1_self_update.html", "class_g_w2___addon___manager_1_1_self_update" ],
    [ "UpdateHelpers", "class_g_w2___addon___manager_1_1_update_helpers.html", null ],
    [ "UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
    [ "UpdatingViewModel", "class_g_w2___addon___manager_1_1_updating_view_model.html", "class_g_w2___addon___manager_1_1_updating_view_model" ],
    [ "UserConfig", "class_g_w2___addon___manager_1_1_user_config.html", "class_g_w2___addon___manager_1_1_user_config" ]
];