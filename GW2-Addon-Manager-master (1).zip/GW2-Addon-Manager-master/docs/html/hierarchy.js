var hierarchy =
[
    [ "GW2_Addon_Manager.AddonYamlReader", "class_g_w2___addon___manager_1_1_addon_yaml_reader.html", null ],
    [ "Application", null, [
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ],
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ],
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ],
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ],
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ],
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ],
      [ "GW2_Addon_Manager::App", "class_g_w2___addon___manager_1_1_app.html", null ]
    ] ],
    [ "ApplicationSettingsBase", null, [
      [ "GW2_Addon_Manager::Properties::Settings", "class_g_w2___addon___manager_1_1_properties_1_1_settings.html", null ]
    ] ],
    [ "GW2_Addon_Manager.ApprovedList", "class_g_w2___addon___manager_1_1_approved_list.html", null ],
    [ "GW2_Addon_Manager.Configuration", "class_g_w2___addon___manager_1_1_configuration.html", null ],
    [ "GW2_Addon_Manager.GenericUpdater", "class_g_w2___addon___manager_1_1_generic_updater.html", null ],
    [ "IComponentConnector", null, [
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::Resources::Components::dropdown", "class_g_w2___addon___manager_1_1_resources_1_1_components_1_1dropdown.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Updater::Add_On_Selector", "class_g_w2___addon___updater_1_1_add___on___selector.html", null ],
      [ "GW2_Addon_Updater::Add_On_Selector", "class_g_w2___addon___updater_1_1_add___on___selector.html", null ],
      [ "GW2_Addon_Updater::Updating", "class_g_w2___addon___updater_1_1_updating.html", null ],
      [ "GW2_Addon_Updater::Updating", "class_g_w2___addon___updater_1_1_updating.html", null ]
    ] ],
    [ "INotifyPropertyChanged", null, [
      [ "GW2_Addon_Manager.AddonInfo", "class_g_w2___addon___manager_1_1_addon_info.html", null ],
      [ "GW2_Addon_Manager.OpeningViewModel", "class_g_w2___addon___manager_1_1_opening_view_model.html", null ],
      [ "GW2_Addon_Manager.UpdatingViewModel", "class_g_w2___addon___manager_1_1_updating_view_model.html", null ]
    ] ],
    [ "InternalTypeHelper", null, [
      [ "XamlGeneratedNamespace::GeneratedInternalTypeHelper", "class_xaml_generated_namespace_1_1_generated_internal_type_helper.html", null ],
      [ "XamlGeneratedNamespace::GeneratedInternalTypeHelper", "class_xaml_generated_namespace_1_1_generated_internal_type_helper.html", null ]
    ] ],
    [ "GW2_Addon_Manager.LoaderSetup", "class_g_w2___addon___manager_1_1_loader_setup.html", null ],
    [ "NavigationWindow", null, [
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ],
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ]
    ] ],
    [ "NavigationWindow", null, [
      [ "GW2_Addon_Manager::MainWindow", "class_g_w2___addon___manager_1_1_main_window.html", null ]
    ] ],
    [ "Page", null, [
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ]
    ] ],
    [ "Page", null, [
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::AddOnSelector", "class_g_w2___addon___manager_1_1_add_on_selector.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Manager::UpdatingView", "class_g_w2___addon___manager_1_1_updating_view.html", null ],
      [ "GW2_Addon_Updater::Add_On_Selector", "class_g_w2___addon___updater_1_1_add___on___selector.html", null ],
      [ "GW2_Addon_Updater::Add_On_Selector", "class_g_w2___addon___updater_1_1_add___on___selector.html", null ],
      [ "GW2_Addon_Updater::Updating", "class_g_w2___addon___updater_1_1_updating.html", null ],
      [ "GW2_Addon_Updater::Updating", "class_g_w2___addon___updater_1_1_updating.html", null ]
    ] ],
    [ "GW2_Addon_Manager.PluginManagement", "class_g_w2___addon___manager_1_1_plugin_management.html", null ],
    [ "GW2_Addon_Manager::Properties::Resources", "class_g_w2___addon___manager_1_1_properties_1_1_resources.html", null ],
    [ "GW2_Addon_Manager.SelfUpdate", "class_g_w2___addon___manager_1_1_self_update.html", null ],
    [ "GW2_Addon_Manager.UpdateHelpers", "class_g_w2___addon___manager_1_1_update_helpers.html", null ],
    [ "GW2_Addon_Manager.UserConfig", "class_g_w2___addon___manager_1_1_user_config.html", null ],
    [ "UserControl", null, [
      [ "GW2_Addon_Manager::Resources::Components::dropdown", "class_g_w2___addon___manager_1_1_resources_1_1_components_1_1dropdown.html", null ]
    ] ]
];