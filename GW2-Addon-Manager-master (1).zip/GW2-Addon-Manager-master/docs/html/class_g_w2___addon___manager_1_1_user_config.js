var class_g_w2___addon___manager_1_1_user_config =
[
    [ "application_version", "class_g_w2___addon___manager_1_1_user_config.html#a2abce3f758c5f304aeacef6f9fa43e55", null ],
    [ "bin_folder", "class_g_w2___addon___manager_1_1_user_config.html#a276a91d5148fe0edf8e0195ac8e94a6a", null ],
    [ "default_configuration", "class_g_w2___addon___manager_1_1_user_config.html#aa442664a08f98670df154f89f20196c5", null ],
    [ "disabled", "class_g_w2___addon___manager_1_1_user_config.html#a84c3a663566d1e4bb52bf5a1059015f9", null ],
    [ "game_path", "class_g_w2___addon___manager_1_1_user_config.html#ab48e149a2c742845b4ea6ea58242d3fc", null ],
    [ "installed", "class_g_w2___addon___manager_1_1_user_config.html#ad08386f12857ef2618cafb7a2e25b997", null ],
    [ "isupdate", "class_g_w2___addon___manager_1_1_user_config.html#a5fd7da50d735c7e9660d156fc296ea03", null ],
    [ "loader_version", "class_g_w2___addon___manager_1_1_user_config.html#a3830b1ee74dbad46a0d121651063dec9", null ],
    [ "version", "class_g_w2___addon___manager_1_1_user_config.html#a511276e383a696a4fddce7be7cfb379d", null ]
];