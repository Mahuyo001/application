var class_g_w2___addon___manager_1_1_addon_info =
[
    [ "addon_name", "class_g_w2___addon___manager_1_1_addon_info.html#a1381e6a906b74b4dec509d528531a906", null ],
    [ "alternate_plugin_names", "class_g_w2___addon___manager_1_1_addon_info.html#a0f218803c2c51dfdb695ec36f1827ca3", null ],
    [ "conflicts", "class_g_w2___addon___manager_1_1_addon_info.html#afe00110bd0287c997a2386544f034d6d", null ],
    [ "description", "class_g_w2___addon___manager_1_1_addon_info.html#a812a5ebb103d596e5c81f873aeb73ac9", null ],
    [ "developer", "class_g_w2___addon___manager_1_1_addon_info.html#a658ea9b2e01ff722a7bb54fa55162503", null ],
    [ "download_type", "class_g_w2___addon___manager_1_1_addon_info.html#a4bc18cc23355423ddcdc12f0aef1e663", null ],
    [ "folder_name", "class_g_w2___addon___manager_1_1_addon_info.html#aa383e120dee49ad56af2f51bc57ae24f", null ],
    [ "host_type", "class_g_w2___addon___manager_1_1_addon_info.html#aa646dd477cce6910b170ff97e7c407ab", null ],
    [ "host_url", "class_g_w2___addon___manager_1_1_addon_info.html#a2c27e4fc95a1ca7aeb53801964ad25cd", null ],
    [ "install_mode", "class_g_w2___addon___manager_1_1_addon_info.html#a7d6468efc3e0e3c64a27e6443928281e", null ],
    [ "IsSelected", "class_g_w2___addon___manager_1_1_addon_info.html#a70f5f94c25644c87d323a793037a1100", null ],
    [ "plugin_name", "class_g_w2___addon___manager_1_1_addon_info.html#a367a1cf92134b4561929d756b9392353", null ],
    [ "requires", "class_g_w2___addon___manager_1_1_addon_info.html#af1b0fe5203f007ea408193bdec553ef5", null ],
    [ "tooltip", "class_g_w2___addon___manager_1_1_addon_info.html#ae4fedec0fe1827cb810ad37965fef0ad", null ],
    [ "version_url", "class_g_w2___addon___manager_1_1_addon_info.html#a50328319e6ac5f4a0ae00d8295c7e665", null ],
    [ "website", "class_g_w2___addon___manager_1_1_addon_info.html#a5817f238810a45c9c818799b1e30cac6", null ],
    [ "PropertyChanged", "class_g_w2___addon___manager_1_1_addon_info.html#a2b5b8cef709a8b9261f8cadfa53a7265", null ]
];