var class_g_w2___addon___manager_1_1_loader_setup =
[
    [ "LoaderSetup", "class_g_w2___addon___manager_1_1_loader_setup.html#ab6b79a69e178535f4ccf84e2625c726e", null ],
    [ "handleLoaderInstall", "class_g_w2___addon___manager_1_1_loader_setup.html#a156db18b5e170cac63ef089ca46d0211", null ]
];