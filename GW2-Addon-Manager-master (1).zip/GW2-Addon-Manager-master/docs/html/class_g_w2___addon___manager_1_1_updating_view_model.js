var class_g_w2___addon___manager_1_1_updating_view_model =
[
    [ "UpdatingViewModel", "class_g_w2___addon___manager_1_1_updating_view_model.html#a203d7b6b175c5f1a8faac9d480ffe450", null ],
    [ "propertyChanged", "class_g_w2___addon___manager_1_1_updating_view_model.html#a3fb3ccda33c0ef00babc9aff1573ede7", null ],
    [ "closeButtonEnabled", "class_g_w2___addon___manager_1_1_updating_view_model.html#a09ddfbd07abc80fbc758fb233e7e11cf", null ],
    [ "label", "class_g_w2___addon___manager_1_1_updating_view_model.html#a7e37d237a5154a1110d7f2b36777ada6", null ],
    [ "showProgress", "class_g_w2___addon___manager_1_1_updating_view_model.html#ab2bb275615390f4c6530cb567613bb10", null ],
    [ "PropertyChanged", "class_g_w2___addon___manager_1_1_updating_view_model.html#a75e743d2a78e3f48ca41656e7552a0eb", null ]
];