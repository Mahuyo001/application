//{{NO_DEPENDENCIES}}
#define IDR_SHADERS   104

#define IDR_BG        200

#define IDR_MOUNTS    211
#define IDR_MOUNT1    211
#define IDR_MOUNT2    212
#define IDR_MOUNT3    213
#define IDR_MOUNT4    214
#define IDR_MOUNT5    215
#define IDR_MOUNT6    216
#define IDR_MOUNT7    217
#define IDR_MOUNT8    218
#define IDR_MOUNT9    219
#define IDR_MOUNT10   220

#define IDR_NOVELTIES 241
#define IDR_NOVELTY1  241
#define IDR_NOVELTY2  242
#define IDR_NOVELTY3  243
#define IDR_NOVELTY4  244
#define IDR_NOVELTY5  245
#define IDR_NOVELTY6  246
#define IDR_NOVELTY7  247
#define IDR_NOVELTY8  248
#define IDR_NOVELTY9  249

#define IDR_MARKERS   261
#define IDR_MARKER1   261
#define IDR_MARKER2   262
#define IDR_MARKER3   263
#define IDR_MARKER4   264
#define IDR_MARKER5   265
#define IDR_MARKER6   266
#define IDR_MARKER7   267
#define IDR_MARKER8   268
#define IDR_MARKER9   269
