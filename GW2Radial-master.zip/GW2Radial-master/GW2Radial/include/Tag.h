#pragma once
#include <neargye/semver.hpp>

static constexpr semver::version CurrentVersion{ 2, 3, 0 };