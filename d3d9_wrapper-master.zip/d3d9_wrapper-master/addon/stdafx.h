﻿#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN  
#include <windows.h>
#include <d3d9.h>
#include <d3d11_4.h>
#include "../include/gw2al_api.h"
#include "com_wrapper.h"
#include "com_wrapper_method_dcl.h"
#include "d3d9_wrapper.h"
